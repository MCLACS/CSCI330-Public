#ifndef PROCEDURAL_H
#define PROCEDURAL_H

double sum(double ary[], int size);
double average(double ary[], int size);
double max(double ary[], int size);
double min(double ary[], int size);
double range(double ary[], int size);

#endif
